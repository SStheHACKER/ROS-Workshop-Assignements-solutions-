#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import math

class LShapeMover:
    def __init__(self):
        # Initialize the node
        rospy.init_node('lshape_mover', anonymous=True)
        self.velocity_publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        self.pose_subscriber = rospy.Subscriber('/turtle1/pose', Pose, self.update_pose)
        self.pose = Pose()
        self.rate = rospy.Rate(10)  # 10 Hz

    def update_pose(self, data):
        """Callback function to update the robot's pose."""
        self.pose = data

    def move_straight(self, distance):
        """Move the robot straight for a specified distance."""
        vel_msg = Twist()

        # Calculate the starting position
        start_x = self.pose.x
        start_y = self.pose.y

        vel_msg.linear.x = 1.0  # Set a constant linear velocity
        while not rospy.is_shutdown():
            # Calculate distance moved
            current_distance = math.sqrt((self.pose.x - start_x)**2 + (self.pose.y - start_y)**2)
            if current_distance >= distance:
                break
            self.velocity_publisher.publish(vel_msg)
            self.rate.sleep()

        # Stop the robot after moving the required distance
        vel_msg.linear.x = 0
        self.velocity_publisher.publish(vel_msg)

    def rotate(self, angle):
        """Rotate the robot to a specified angle (in radians)."""
        vel_msg = Twist()
        vel_msg.angular.z = 1.0  # Set a constant angular velocity

        # Convert angle from degrees to radians
        angle_radians = angle * (math.pi / 180.0)

        # Get the current yaw orientation of the turtle
        initial_yaw = self.pose.theta

        while not rospy.is_shutdown():
            current_yaw = self.pose.theta
            relative_yaw = abs(current_yaw - initial_yaw)

            if relative_yaw >= angle_radians:
                break
            self.velocity_publisher.publish(vel_msg)
            self.rate.sleep()

        # Stop the rotation after reaching the required angle
        vel_msg.angular.z = 0
        self.velocity_publisher.publish(vel_msg)

    def lshape_movement(self):
        """Plan and execute the L-shaped movement."""
        # Move straight for 5 units
        self.move_straight(5.0)

        # Perform a 90-degree turn (yaw rotation)
        self.rotate(90)

        # Move straight again for 3 units
        self.move_straight(3.0)


if __name__ == '__main__':
    try:
        lshape_mover = LShapeMover()
        rospy.sleep(1)  # Give time to initialize the subscriber
        lshape_mover.lshape_movement()
    except rospy.ROSInterruptException:
        pass
