#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
import sys
import select
import tty
import termios

# Initialize the keyboard controller
class KeyboardController:
    def __init__(self):
        rospy.init_node('keyboard_controller', anonymous=True)
        self.velocity_publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        self.rate = rospy.Rate(10) # 10hz
        self.key_bindings = {
            'w': (1, 0),   # Forward
            's': (-1, 0),  # Backward
            'a': (0, 1),   # Rotate left
            'd': (0, -1)   # Rotate right
        }

    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        if rlist:
            return sys.stdin.read(1)
        else:
            return ''

    def run(self):
        twist = Twist()
        while not rospy.is_shutdown():
            key = self.get_key()
            if key in self.key_bindings:
                twist.linear.x = self.key_bindings[key][0]
                twist.angular.z = self.key_bindings[key][1]
            else:
                twist.linear.x = 0
                twist.angular.z = 0
            self.velocity_publisher.publish(twist)
            self.rate.sleep()

if __name__ == '__main__':
    settings = termios.tcgetattr(sys.stdin)
    controller = KeyboardController()
    try:
        controller.run()
    except rospy.ROSInterruptException:
        pass
    #finally:
        #termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
