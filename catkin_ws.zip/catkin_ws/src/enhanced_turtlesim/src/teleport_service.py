#!/usr/bin/env python3
import rospy
import random
from turtlesim.srv import TeleportAbsolute

class TeleportTurtle:
    def __init__(self):
        rospy.init_node('teleport_service', anonymous=True)
        self.teleport_service = rospy.Service('teleport_turtle', TeleportAbsolute, self.handle_teleport)

    def handle_teleport(self, req):
        x = random.uniform(1.0, 10.0)
        y = random.uniform(1.0, 10.0)
        rospy.wait_for_service('/turtle1/teleport_absolute')
        try:
            teleport_turtle = rospy.ServiceProxy('/turtle1/teleport_absolute', TeleportAbsolute)
            teleport_turtle(x, y, random.uniform(0, 6.28))
            return True
        except rospy.ServiceException as e:
            rospy.logerr(f"Service call failed: {e}")
            return False

if __name__ == '__main__':
    TeleportTurtle()
    rospy.spin()
