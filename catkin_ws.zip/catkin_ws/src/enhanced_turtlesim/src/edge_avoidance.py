#!/usr/bin/env python3
import rospy
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist

class EdgeAvoidance:
    def __init__(self):
        rospy.init_node('edge_avoidance', anonymous=True)
        self.pose_subscriber = rospy.Subscriber('/turtle1/pose', Pose, self.update_pose)
        self.velocity_publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        self.pose = Pose()
        self.rate = rospy.Rate(10)

    def update_pose(self, data):
        self.pose = data

    def avoid_edges(self):
        while not rospy.is_shutdown():
            twist = Twist()
            if self.pose.x < 1.0 or self.pose.x > 10.5 or self.pose.y < 1.0 or self.pose.y > 10.5:
                twist.linear.x = -1.0  # Move backward if at the edge
            else:
                twist.linear.x = 0.0
            self.velocity_publisher.publish(twist)
            self.rate.sleep()

if __name__ == '__main__':
    try:
        node = EdgeAvoidance()
        node.avoid_edges()
    except rospy.ROSInterruptException:
        pass
